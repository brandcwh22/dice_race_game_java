public class Dice {
    public static int diceRoll (){
        int diceRoll = (int)(Math.random()*6)+1;
        return diceRoll;
    }
}
