public class GameTest {

    public static void main(String[] args) {
        GameMenu startgame = new GameMenu();
        startgame.startGame(); //starts the game
    }
}
